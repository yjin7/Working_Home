## ▣ PARA Method

![|500](https://i.imgur.com/jm6gccf.png)

![|500](https://i.imgur.com/TtTT0qd.png)
![|650](https://i.imgur.com/WP4AZPJ.png)

#### ▶ PROJECT
- 목표와 데드라인이 명확한, 주로 단기적인 과업
![650](https://i.imgur.com/di4IALO.png)
- Complete webpage design
- Buy a new computer
- Write research report
- Renovate the bathroom
- Finish Spanish language course
- Set up new living room furniture

#### ▶ AREA (of responsibility)
- 인생을 살면서 지속적으로 신경을 써야하는 것들
- 목표 (Goal)
![700](https://i.imgur.com/fdk9l5f.png)
- Work responsibilities such as Marketing, Human Resources, Product Management, Research and Development, Direct Reports, or Engineering (일적 책임)
- Personal responsibilities such as Health, Finances, Kids, Writing, Car, or Home (개인적 책임)


#### ▶ PROJECT vs AREA
![700](https://i.imgur.com/VUMvSMw.png)
- **Project-Area**

|  Project   | Area |
| :--------: | :--: |
| 24년 마라톤 완주 |  건강  |
|  24년 책 출판  | 글쓰기  |
|  8월 여름휴가   |  여행  |
- **Area-Project-Task**
![700](https://i.imgur.com/l3nKc13.png)
![700](https://i.imgur.com/1XRN6B1.png)

#### ▶ RESOURCE
- 자료나 관심 있는 것들을 주제별로 모아둔 것
![700](https://i.imgur.com/z2kftNL.png)
- Active Resource (사용 중인 리소스)
- In-Active Resource (현재 미사용 리소스)
- Shareable Resource (공유용 리소스)

- Graphic design
- Personal productivity
- Organic gardening
- Coffee
- Modern architecture
- Web design
- Japanese language
- French literature
- Notetaking
- Breathwork
- Habit formation
- Photography
- Marketing assets

#### ▶ ARCHIVE
- 현 시점에 필요없어진 것들을 모아두는 장소
- 미래의 내가 잘 찾아볼 수 있도록만 관리하면 됨
![700](https://i.imgur.com/tuC8oiQ.png)
- Projects you’ve completed or put on hold
- Areas that are no longer active or relevant
- Resources that you’re no longer interested in


## ▣ Floder Icon
- Album : Normal Floder
- Archive : Archive Floder
- Badge : 진행
- BadgeCheck : 완료
- BadX : 중단




