---
Title: YYMM-0W. English Book Title
Start: 
End: 
Category:
  - Reading
Type:
  - Online Lecture
Source: 
Note:
---
## ▣ ‘YY.MM English Book Title  Korean Book Title

#### ◑ MM/DD - Day 01.
###### ⊙ PREVIOUSLY ON
>[!summary]
>

###### ⊙ READING
- Chapter 01.
###### ⊙ FREE TALK
- Q.
- A. <u>__________</u> .
- Dialog
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Me : <u>__________</u> .
    - Mariyah : Oh, I see.
		오, 그렇구나.
###### ⊙ WRITING
>[!quote]
>

#### ◑ MM/DD - Day 01.
###### ⊙ PREVIOUSLY ON
>[!summary]

###### ⊙ READING
- Chapter 01.
###### ⊙ FREE TALK
- Q.
- A. <u>__________</u> .
- Dialog
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Me : <u>__________</u> .
    - Mariyah : Oh, I see.
		오, 그렇구나.
###### ⊙ WRITING
>[!quote]
>

#### ◑ MM/DD - Day 01.
###### ⊙ PREVIOUSLY ON
>[!summary]

###### ⊙ READING
- Chapter 01.
###### ⊙ FREE TALK
- Q.
- A. <u>__________</u> .
- Dialog
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Me : <u>__________</u> .
    - Mariyah : Oh, I see.
		오, 그렇구나.
###### ⊙ WRITING
>[!quote]
>

#### ◑ MM/DD - Day 01.
###### ⊙ PREVIOUSLY ON
>[!summary]

###### ⊙ READING
- Chapter 01.
###### ⊙ FREE TALK
- Q.
- A. <u>__________</u> .
- Dialog
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Me : <u>__________</u> .
    - Mariyah : Oh, I see.
		오, 그렇구나.
###### ⊙ WRITING
>[!quote]
>

#### ◑ MM/DD - Day 01.
###### ⊙ PREVIOUSLY ON
>[!summary]

###### ⊙ READING
- Chapter 01.
###### ⊙ FREE TALK
- Q.
- A. <u>__________</u> .
- Dialog
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Mariyah :
    - Josh :
    - Me : <u>__________</u> .
    - Mariyah : Oh, I see.
		오, 그렇구나.
###### ⊙ WRITING
>[!quote]
>





