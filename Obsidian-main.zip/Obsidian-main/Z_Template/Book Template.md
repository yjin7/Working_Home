---
Title: "{{title}}"
Author: "[{{author}}]"
Publisher: "{{publisher}}"
Publish_Date: "{{publishDate}}"
TotalPage: "{{totalPage}}"
Cover: "{{coverUrl}}"
Start_Date: 
Finish_Date: 
Source: 
  - Book
  - e-Book
  - PDF File
  - Other File
Category:
  - 소설/희곡
  - 시/에세이
  - 경제/경영
  - 자기계발
  - 인문
  - 역사/문학
  - 정치/사회
  - 예술/건축
  - 과학/기술/공학
  - 컴퓨터/IT
  - 건강/여행/요리
  - 취미/실용/스포츠
  - 잡지/만화
  - 어학/학습
  - 영어
Status:
  - 🟦 읽는중
  - 🟧 예정
  - 🟨 중단
  - 🟩 완료
Rating: ★★★★★
---
## {{title}}

#### ▣ 읽기 전 생각
%% 읽기전 표지나 서문을 보고 든 생각 %%




#### ▣ 읽은 후 생각
%% 읽은 후 첫 인상과 달랐거나 중요하게 생각한 부분 %%




#### ▣ 정리
%% 마음에 와닿는 문장이나 중요하다고 생각하는 부분 %%




#### ▣ 액션 아이템
%% 이 책을 읽고 내 삶에 적용할 수 있는 조언이나 실행계획 %%




