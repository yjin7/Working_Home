- 커뮤니티 플러그인 (Browse) 에서 플러그인 검색하여 설치 후 활성화

## 1. Excalidraw
- 
![](https://i.imgur.com/xzVYx0V.png)

![](https://i.imgur.com/uFtnjyp.png)


![](https://i.imgur.com/1Sggz4j.png)
![](https://i.imgur.com/x1p7Xoh.png)









