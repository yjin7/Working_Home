## 📚 2024년 독서 노트

#### 🟦 읽고 있는 책
```dataview
TABLE without id
    file.link as "도서명",
    Author as "저자",
    ("![coverimg|35](" + Cover+ ")") as "북커버",
    Category as "카테고리",
    TotalPage as "전체 페이지", 
    dateformat(Start_Date, "yyyMMdd") as "시작일",
    dateformat(Finish_Date, "yyyMMdd") as "완료일",
    (date(Finish_Date) - date(Start_Date)) as "기간",
    Rating as "내 평점"
FROM "G_Book_Reviews/2024" 
WHERE Status = "🟦 읽는중" and !contains(file.path, "Template")
SORT Start_Date desc
```


#### 🟧 읽을 책
```dataview
TABLE without id
    file.link as "도서명",
    Author as "저자",
    ("![coverimg|35](" + Cover+ ")") as "북커버",
    Category as "카테고리",
    TotalPage as "전체 페이지", 
    dateformat(Start_Date, "yyyMMdd") as "시작일",
    dateformat(Finish_Date, "yyyMMdd") as "완료일",
    (date(Finish_Date) - date(Start_Date)) as "기간",
    Rating as "내 평점"
FROM "G_Book_Reviews/2024" 
WHERE Status = "🟧 예정" and !contains(file.path, "Template")
SORT Start_Date desc
```


#### 🟩 다 읽은 책
```dataview
TABLE without id
    file.link as "도서명",
    Author as "저자",
    ("![coverimg|35](" + Cover+ ")") as "북커버",
    Category as "카테고리",
    TotalPage as "전체 페이지", 
    dateformat(Start_Date, "yyyMMdd") as "시작일",
    dateformat(Finish_Date, "yyyMMdd") as "완료일",
    (date(Finish_Date) - date(Start_Date)) as "기간",
    Rating as "내 평점"
FROM "G_Book_Reviews/2024" 
SORT Finish_Date DESC
WHERE Status = "🟩 완료"
```


#### 🟨 읽다가 멈춘 책
```dataview
TABLE without id
    file.link as "도서명",
    Author as "저자",
    ("![coverimg|35](" + Cover+ ")") as "북커버",
    Category as "카테고리",
    TotalPage as "전체 페이지", 
    dateformat(Start_Date, "yyyMMdd") as "시작일",
    dateformat(Finish_Date, "yyyMMdd") as "완료일",
    (date(Finish_Date) - date(Start_Date)) as "기간",
    Rating as "내 평점"
FROM "G_Book_Reviews/2024" 
WHERE Status = "🟨 중단" and !contains(file.path, "Template")
SORT Start_Date desc
```

