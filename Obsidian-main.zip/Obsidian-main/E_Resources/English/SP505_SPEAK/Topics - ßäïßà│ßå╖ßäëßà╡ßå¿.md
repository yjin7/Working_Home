# ▣ 야식의 유혹

##### ◑ 10/01 (TUE)
- late-night cravings
	- Nothing beats fried chicken for late night food cravings.
		야식이 땡길 때는 치킨이 최고야.
	- Nothing beats ramen for late night food cravings.
		야식이 땡길 때는 라면이 최고야.
- fruity drinks
- ingredients

