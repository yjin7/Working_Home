``` dataview
TABLE without ID
	link(file.path, Title) as "Name",
	dateformat(Start, "yyyy-MM-dd") + " → " + dateformat(End, "yyyy-MM-dd") as "Date",
	Category,
	Type,
	Source,
	Note,
	file.mtime as "Modified"
FROM "E_Resources/English/RE101_She Dining"
WHERE start AND end AND title
SORT file.name ASC
```
